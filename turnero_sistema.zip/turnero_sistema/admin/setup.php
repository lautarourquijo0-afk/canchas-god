<?php
/* ============================================================
   SETUP — ejecutá esto UNA sola vez entrando a /admin/setup.php
   Crea los dos usuarios iniciales del panel y después
   TE PEDIMOS QUE BORRES ESTE ARCHIVO por seguridad.
   ============================================================ */

require __DIR__ . '/../conexion.php';

$usuarios = [
    ['admin',     'admin123',     'admin'],
    ['recepcion', 'recepcion123', 'recepcion'],
];

echo '<meta charset="utf-8"><body style="font-family:sans-serif;max-width:560px;margin:40px auto;line-height:1.6">';
echo '<h2>Configuración inicial del turnero</h2>';

try {
    $stmt = $pdo->prepare(
        "INSERT INTO usuarios (usuario, clave_hash, rol) VALUES (?,?,?)
         ON DUPLICATE KEY UPDATE clave_hash = VALUES(clave_hash), rol = VALUES(rol)"
    );
    foreach ($usuarios as [$u, $p, $r]) {
        $stmt->execute([$u, password_hash($p, PASSWORD_DEFAULT), $r]);
        echo "✅ Usuario <b>$u</b> (rol: $r) — contraseña: <code>$p</code><br>";
    }
    echo '<hr><p style="color:#b02820"><b>Importante:</b> cambiá estas contraseñas y '
       . '<b>borrá este archivo (setup.php)</b> del servidor.</p>';
    echo '<p><a href="login.php">→ Ir al panel de administración</a></p>';
} catch (Throwable $e) {
    echo '<p style="color:red">Error: ' . htmlspecialchars($e->getMessage()) . '</p>';
    echo '<p>¿Importaste el archivo <code>db.sql</code> y configuraste <code>config.php</code>?</p>';
}
