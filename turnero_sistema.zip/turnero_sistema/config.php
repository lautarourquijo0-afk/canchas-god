<?php
/* ============================================================
   CONFIGURACIÓN  —  editá SOLO este archivo para conectar la base
   ============================================================
   Los datos te los da Alwaysdata cuando creás la base MySQL:
   Panel de Alwaysdata  →  "Bases de datos"  →  "MySQL"
   ============================================================ */

return [

  'db' => [
    'host'    => 'mysql-TUUSUARIO.alwaysdata.net',  // Host que te da Alwaysdata
    'nombre'  => 'tuusuario_turnero',               // Nombre de la base
    'usuario' => 'tuusuario',                        // Usuario MySQL
    'clave'   => 'TU_CONTRASEÑA',                    // Contraseña MySQL
  ],

  // Zona horaria: hace que el reloj y el "En juego" usen la hora argentina.
  'zona_horaria' => 'America/Argentina/Buenos_Aires',

];
