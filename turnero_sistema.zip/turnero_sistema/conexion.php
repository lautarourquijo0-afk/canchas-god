<?php
/* Conexión a la base de datos (no hace falta tocar este archivo). */

$cfg = require __DIR__ . '/config.php';

date_default_timezone_set($cfg['zona_horaria'] ?? 'America/Argentina/Buenos_Aires');

try {
    $pdo = new PDO(
        "mysql:host={$cfg['db']['host']};dbname={$cfg['db']['nombre']};charset=utf8mb4",
        $cfg['db']['usuario'],
        $cfg['db']['clave'],
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die('Error de conexión a la base de datos. Revisá config.php · ' . $e->getMessage());
}
